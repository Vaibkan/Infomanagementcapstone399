import React from "react";
import { cn } from "@/lib/utils";

// Small unobtrusive "Synthetic data" label shown in the header.
export default function SyntheticBadge({ className }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-amber/30 bg-amber-soft px-2.5 py-1 text-[11px] font-medium text-amber",
        className
      )}
      title="All records in this prototype are fictional. No real student data is used."
    >
      <span className="h-1.5 w-1.5 rounded-full bg-amber" />
      Synthetic data
    </span>
  );
}