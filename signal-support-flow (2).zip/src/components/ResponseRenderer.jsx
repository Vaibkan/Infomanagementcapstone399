import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, TrendingUp } from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  Cell,
} from "recharts";
import StudentResultCard from "@/components/StudentResultCard";
import { Button } from "@/components/ui/button";

function Markdown({ text }) {
  // minimal bold parsing
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return (
    <p className="text-[15px] leading-relaxed text-foreground">
      {parts.map((p, i) =>
        p.startsWith("**") && p.endsWith("**") ? (
          <strong key={i} className="font-semibold">{p.slice(2, -2)}</strong>
        ) : (
          <React.Fragment key={i}>{p}</React.Fragment>
        )
      )}
    </p>
  );
}

function MetricGrid({ metrics }) {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      {metrics.map((m) => (
        <div key={m.label} className="rounded-xl border border-border/70 bg-muted/40 p-3.5">
          <p className="font-heading text-2xl font-semibold tracking-tight text-foreground">{m.value}</p>
          <p className="text-xs text-muted-foreground">{m.label}</p>
        </div>
      ))}
    </div>
  );
}

function StudentGrid({ students, count }) {
  return (
    <div>
      {count != null && students.length < count && (
        <p className="mb-2 text-xs text-muted-foreground">Showing {students.length} of {count} students.</p>
      )}
      <div className="grid gap-3 sm:grid-cols-2">
        {students.map((c) => (
          <StudentResultCard key={c.student_id} data={c} />
        ))}
      </div>
    </div>
  );
}

function FairnessChart({ rows, overallRate }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <ResponsiveContainer width="100%" height={180}>
        <BarChart data={rows} layout="vertical" margin={{ left: 8, right: 24, top: 8, bottom: 8 }}>
          <CartesianGrid horizontal={false} stroke="hsl(var(--border))" />
          <XAxis type="number" domain={[0, 0.7]} tickFormatter={(v) => `${Math.round(v * 100)}%`} fontSize={11} stroke="hsl(var(--muted-foreground))" />
          <YAxis type="category" dataKey="group" fontSize={12} stroke="hsl(var(--muted-foreground))" width={40} />
          <Tooltip formatter={(v) => `${Math.round(v * 100)}%`} contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))" }} />
          <Bar dataKey="rate" radius={[0, 6, 6, 0]} name="Review rate">
            {rows.map((r, i) => (
              <Cell key={i} fill={r.rate >= overallRate ? "hsl(var(--teal))" : "hsl(var(--violet))"} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      <p className="mt-2 text-xs text-muted-foreground">Bars show each fictional group's review rate. The cohort rate is {Math.round(overallRate * 100)}%.</p>
    </div>
  );
}

function TrendChart({ trend }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <ResponsiveContainer width="100%" height={200}>
        <LineChart data={trend} margin={{ left: -16, right: 12, top: 8, bottom: 4 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
          <XAxis dataKey="week" fontSize={11} stroke="hsl(var(--muted-foreground))" />
          <YAxis fontSize={11} stroke="hsl(var(--muted-foreground))" />
          <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))" }} />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Line type="monotone" dataKey="listed" name="Listed" stroke="hsl(var(--teal))" strokeWidth={2.5} dot={{ r: 3 }} connectNulls />
          <Line type="monotone" dataKey="unlisted" name="Not listed" stroke="hsl(var(--violet))" strokeWidth={2.5} dot={{ r: 3 }} connectNulls />
        </LineChart>
      </ResponsiveContainer>
      <p className="mt-2 text-xs text-muted-foreground">Average recorded Canvas sessions per week. Null values excluded from each average.</p>
    </div>
  );
}

export default function ResponseRenderer({ response, onFollowUp }) {
  if (!response) return null;
  return (
    <div className="space-y-4">
      <Markdown text={response.answer} />

      {response.metrics && <MetricGrid metrics={response.metrics} />}

      {response.fairnessRows && <FairnessChart rows={response.fairnessRows} overallRate={response.overallRate} />}

      {response.trend && <TrendChart trend={response.trend} />}

      {response.students && response.students.length > 0 && (
        <StudentGrid students={response.students} count={response.studentCount} />
      )}

      {response.decisions && response.decisions.length > 0 && (
        <div className="space-y-2">
          {response.decisions.map((d) => (
            <div key={d.id} className="rounded-xl border border-border bg-card p-3 text-sm">
              <span className="font-medium text-foreground">{d.display_name || d.student_id}</span>
              <span className="text-muted-foreground"> · {d.outcome === "accept" ? "Accepted next step" : d.outcome === "follow-up" ? "Follow up later" : "No action"}</span>
              {d.chosenCategory && <span className="text-muted-foreground"> · {d.chosenCategory}</span>}
            </div>
          ))}
        </div>
      )}

      {response.openPath && (
        <Link to={response.openPath}>
          <Button size="sm" className="gap-1.5">
            {response.openLabel || "Open"} <ArrowRight className="h-4 w-4" />
          </Button>
        </Link>
      )}

      {response.followUps && response.followUps.length > 0 && (
        <div className="flex flex-wrap gap-2 pt-1">
          {response.followUps.map((q, i) => (
            <button
              key={i}
              onClick={() => onFollowUp?.(q)}
              className="rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:border-violet/40 hover:text-violet"
            >
              {q}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}