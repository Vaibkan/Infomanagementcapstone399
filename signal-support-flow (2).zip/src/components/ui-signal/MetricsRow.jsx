import React from "react";
import { cn } from "@/lib/utils";

// Compact horizontal summary strip: label + value pairs in a single elegant row.
const TONES = {
  neutral: "text-foreground",
  teal: "text-teal",
  violet: "text-violet",
  amber: "text-amber",
};

export default function MetricsRow({ items, className }) {
  return (
    <div
      className={cn(
        "flex flex-wrap items-center gap-x-10 gap-y-4 rounded-2xl border border-border bg-card px-6 py-4 shadow-soft",
        className
      )}
    >
      {items.map((item) => (
        <div key={item.label} className="min-w-[110px]">
          <p className={cn("font-heading text-2xl font-semibold tracking-tight", TONES[item.tone] || TONES.neutral)}>
            {item.value}
          </p>
          <p className="mt-0.5 text-xs font-medium text-muted-foreground">{item.label}</p>
        </div>
      ))}
    </div>
  );
}