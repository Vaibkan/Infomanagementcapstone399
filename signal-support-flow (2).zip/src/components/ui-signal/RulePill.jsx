import React from "react";
import { cn } from "@/lib/utils";

const STYLES = {
  Matched: "bg-teal-soft text-teal border-teal/20",
  "Not matched": "bg-muted text-muted-foreground border-border",
  "Could not check": "bg-amber-soft text-amber border-amber/20",
};

export default function RulePill({ outcome, className, small }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border font-medium",
        STYLES[outcome] || STYLES["Not matched"],
        small ? "px-2 py-0.5 text-[11px]" : "px-2.5 py-1 text-xs",
        className
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full",
        outcome === "Matched" ? "bg-teal" : outcome === "Could not check" ? "bg-amber" : "bg-muted-foreground/50")} />
      {outcome}
    </span>
  );
}