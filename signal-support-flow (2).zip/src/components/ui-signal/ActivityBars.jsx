import React from "react";
import { cn } from "@/lib/utils";

// Mini weekly Canvas activity bars. Null values render as a dashed outline (unrecorded).
export default function ActivityBars({ weeks, height = 36, className }) {
  const max = Math.max(8, ...weeks.map((w) => (w == null ? 0 : w)));
  return (
    <div className={cn("flex items-end gap-1", className)} style={{ height }}>
      {weeks.map((w, i) => {
        const isNull = w == null;
        const h = isNull ? 0 : Math.max(6, (w / max) * (height - 2));
        return (
          <div key={i} className="flex flex-1 flex-col items-center justify-end" style={{ height }}>
            {isNull ? (
              <div
                className="w-full rounded-sm border border-dashed border-border"
                style={{ height: height * 0.45 }}
                title="Not recorded"
              />
            ) : (
              <div
                className={cn("w-full rounded-sm", w === 0 ? "bg-amber/40" : "bg-teal/70")}
                style={{ height: h }}
                title={`Week ${i + 1}: ${w}`}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}