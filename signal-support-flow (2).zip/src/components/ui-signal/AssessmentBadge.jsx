import React from "react";
import { Check, X, MinusCircle } from "lucide-react";
import { cn } from "@/lib/utils";

const MAP = {
  Submitted: { icon: Check, cls: "bg-teal-soft text-teal", label: "Submitted" },
  Missed: { icon: X, cls: "bg-amber-soft text-amber", label: "Missed" },
  "Not recorded": { icon: MinusCircle, cls: "bg-muted text-muted-foreground", label: "Not recorded" },
};

export default function AssessmentBadge({ status, className }) {
  const m = MAP[status] || MAP["Not recorded"];
  const Icon = m.icon;
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-medium", m.cls, className)}>
      <Icon className="h-3.5 w-3.5" />
      {m.label}
    </span>
  );
}