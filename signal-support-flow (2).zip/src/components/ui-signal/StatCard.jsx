import React from "react";
import { cn } from "@/lib/utils";

export default function StatCard({ label, value, sub, icon: Icon, tone = "neutral", className }) {
  const tones = {
    neutral: "text-foreground",
    teal: "text-teal",
    violet: "text-violet",
    amber: "text-amber",
  };
  const bgTones = {
    neutral: "bg-muted",
    teal: "bg-teal-soft",
    violet: "bg-violet-soft",
    amber: "bg-amber-soft",
  };
  return (
    <div className={cn("rounded-2xl border border-border bg-card p-4 shadow-soft", className)}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <span className="text-xs font-medium text-muted-foreground">{label}</span>
          <div className={cn("mt-1.5 font-heading text-2xl font-semibold tracking-tight", tones[tone])}>
            {value}
          </div>
          {sub && <p className="mt-1 text-xs text-muted-foreground">{sub}</p>}
        </div>
        {Icon && (
          <span className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-lg", bgTones[tone])}>
            <Icon className={cn("h-4 w-4", tones[tone])} />
          </span>
        )}
      </div>
    </div>
  );
}