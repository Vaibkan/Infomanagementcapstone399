import React from "react";
import { NavLink } from "react-router-dom";
import {
  MessageSquare,
  ListChecks,
  Users,
  ClipboardCheck,
  Database,
  Scale,
  SlidersHorizontal,
  Info,
  X,
  PanelLeftClose,
  PanelLeftOpen,
  LogOut,
} from "lucide-react";
import Logo from "@/components/Logo";
import { cn } from "@/lib/utils";
import { useAuth } from "@/lib/AuthContext";

const PRIMARY_NAV = [
  { to: "/", label: "Ask SIGNAL", icon: MessageSquare, end: true },
  { to: "/review", label: "Review Queue", icon: ListChecks },
  { to: "/explorer", label: "Students", icon: Users },
  { to: "/decisions", label: "My Decisions", icon: ClipboardCheck },
];

const WORKSPACE_NAV = [
  { to: "/data-quality", label: "Data Quality", icon: Database },
  { to: "/fairness", label: "Fairness Review", icon: Scale },
  { to: "/rule-settings", label: "Rule Settings", icon: SlidersHorizontal },
  { to: "/about", label: "About SIGNAL", icon: Info },
];

export default function Sidebar({ open, onClose, collapsed = false, onToggleCollapsed }) {
  // Collapsed applies on desktop only; the mobile drawer always renders expanded.
  const compact = collapsed && !open;
  const { user, logout } = useAuth();

  const handleSignOut = () => {
    logout(false);
    window.location.href = "/login";
  };

  const renderItem = (item) => {
    const Icon = item.icon;
    return (
      <NavLink
        key={item.to}
        to={item.to}
        end={item.end}
        onClick={onClose}
        title={compact ? item.label : undefined}
        className={({ isActive }) =>
          cn(
            "flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium transition-all duration-200",
            compact ? "mx-auto w-11 justify-center px-0 py-2.5" : "",
            isActive
              ? "bg-teal-soft text-teal"
              : "text-muted-foreground hover:bg-muted/70 hover:text-foreground"
          )
        }
      >
        <Icon className="h-[17px] w-[17px] shrink-0" />
        {!compact && <span className="truncate">{item.label}</span>}
      </NavLink>
    );
  };

  return (
    <>
      {open && (
        <div
          className="fixed inset-0 z-30 bg-foreground/25 backdrop-blur-[2px] lg:hidden"
          onClick={onClose}
        />
      )}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-border bg-card transition-all duration-300 lg:translate-x-0",
          collapsed ? "lg:w-[76px]" : "lg:w-64",
          open ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className={cn("flex items-center justify-between pt-5", compact ? "flex-col gap-3 px-2" : "px-4")}>
          <Logo compact={compact} />
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted lg:hidden"
            aria-label="Close menu"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-5 scrollbar-thin">
          {PRIMARY_NAV.map(renderItem)}

          <p
            className={cn(
              "px-3 pb-1.5 pt-5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70",
              compact && "sr-only"
            )}
          >
            Workspace
          </p>
          {WORKSPACE_NAV.map(renderItem)}
        </nav>

        <div className="px-3 pb-2">
          <button
            onClick={onToggleCollapsed}
            className={cn(
              "hidden items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium text-muted-foreground transition-all duration-200 hover:bg-muted/70 hover:text-foreground lg:flex",
              compact ? "mx-auto w-11 justify-center px-0" : "w-full"
            )}
            aria-label={compact ? "Expand sidebar" : "Collapse sidebar"}
          >
            {compact ? (
              <PanelLeftOpen className="h-[17px] w-[17px]" />
            ) : (
              <>
                <PanelLeftClose className="h-[17px] w-[17px]" />
                Collapse
              </>
            )}
          </button>
        </div>

        <div className={cn("border-t border-border px-3 py-3", compact && "px-2")}>
          {!compact && user?.email && (
            <p className="truncate px-2 pb-2 text-[11px] text-muted-foreground">{user.email}</p>
          )}
          <button
            onClick={handleSignOut}
            title={compact ? "Sign out" : undefined}
            aria-label="Sign out"
            className={cn(
              "flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium text-muted-foreground transition-all duration-200 hover:bg-muted/70 hover:text-foreground",
              compact ? "mx-auto w-11 justify-center px-0" : "w-full"
            )}
          >
            <LogOut className="h-[17px] w-[17px] shrink-0" />
            {!compact && <span>Sign out</span>}
          </button>
        </div>

        {!compact && (
          <div className="border-t border-border px-5 py-4">
            <p className="text-[11px] leading-relaxed text-muted-foreground">
              SIGNAL is an advisor-facing prototype. Advisors retain complete responsibility for decisions.
            </p>
          </div>
        )}
      </aside>
    </>
  );
}