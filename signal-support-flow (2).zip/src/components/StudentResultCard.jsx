import React from "react";
import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import ActivityBars from "@/components/ui-signal/ActivityBars";
import RulePill from "@/components/ui-signal/RulePill";
import { cn } from "@/lib/utils";

// Compact card summarising one student's computed rule results.
export default function StudentResultCard({ data, showActivity = true, className }) {
  const { student, matchedRules, suggestedCategory, results, listedForReview } = data;
  const weeks = ["canvas_sessions_w1", "canvas_sessions_w2", "canvas_sessions_w3", "canvas_sessions_w4"].map(
    (k) => student[k]
  );
  return (
    <Link
      to={`/student/${student.student_id}`}
      className={cn(
        "group block rounded-2xl border border-border bg-card p-4 shadow-sm transition-all duration-200 hover:border-teal/35 hover:shadow-lift",
        className
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate font-semibold text-foreground">{student.display_name}</p>
          <p className="text-xs text-muted-foreground">{student.student_id}</p>
        </div>
        <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:text-teal" />
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-1.5">
        {["R1", "R2", "R3", "R4"].map((k) => (
          <RulePill key={k} outcome={results[k].outcome} small />
        ))}
      </div>
      {showActivity && (
        <div className="mt-3">
          <ActivityBars weeks={weeks} height={28} />
          <div className="mt-1 flex justify-between text-[10px] text-muted-foreground">
            {["W1", "W2", "W3", "W4"].map((w) => (
              <span key={w}>{w}</span>
            ))}
          </div>
        </div>
      )}
      {listedForReview && suggestedCategory !== "None" && (
        <p className="mt-2 text-xs text-muted-foreground">
          Suggested: <span className="font-medium text-foreground">{suggestedCategory}</span>
        </p>
      )}
    </Link>
  );
}