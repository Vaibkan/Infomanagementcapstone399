import React from "react";
import { cn } from "@/lib/utils";

// Brand mark: three overlapping forward arrowheads in periwinkle (#C5C4F1).
export function SignalMark({ className }) {
  return (
    <svg viewBox="0 0 64 40" fill="none" className={cn("h-5 w-8", className)} aria-hidden="true">
      <polygon points="2,4 2,36 26,20" fill="#C5C4F1" opacity="0.55" />
      <polygon points="16,8 16,32 38,20" fill="#C5C4F1" opacity="0.8" />
      <polygon points="30,2 30,38 56,20" fill="#C5C4F1" />
    </svg>
  );
}

// SIGNAL wordmark with the three-arrowhead brand mark.
export default function Logo({ className, compact = false }) {
  if (compact) {
    return <SignalMark className={cn("h-6 w-9", className)} />;
  }
  return (
    <div className={cn("flex select-none flex-col leading-none", className)}>
      <div className="flex items-center gap-1.5">
        <span className="font-heading text-[18px] font-extrabold tracking-tight text-foreground">SIGNAL</span>
        <SignalMark className="h-3.5" />
      </div>
      <span className="mt-1 text-[10px] font-medium tracking-wide text-muted-foreground">Student engagement support</span>
    </div>
  );
}