import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { generateStudentId } from "@/lib/studentId";

const ASSESSMENT_OPTIONS = ["Submitted", "Missed", "Not recorded"];

const EMPTY_FORM = {
  display_name: "",
  course_code: "BUSAN101",
  course_offering_period: "2026S2",
  registration_day: "0",
  canvas_sessions_w1: "",
  canvas_sessions_w2: "",
  canvas_sessions_w3: "",
  canvas_sessions_w4: "",
  quiz1_w2: "Not recorded",
  quiz2_w3: "Not recorded",
  assignment1_plan_w4: "Not recorded",
  synthetic_group: "A",
};

function SectionTitle({ children, hint }) {
  return (
    <div className="flex items-baseline justify-between gap-3">
      <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{children}</h4>
      {hint && <span className="text-[11px] text-muted-foreground/70">{hint}</span>}
    </div>
  );
}

export default function AddStudentDialog({ open, onOpenChange, addStudent, existingIds }) {
  const [form, setForm] = useState(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.display_name.trim()) {
      setError("Enter a display name.");
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const toNum = (v) => (v === "" ? null : Number(v));
      await addStudent({
        display_name: form.display_name.trim(),
        course_code: form.course_code.trim(),
        course_offering_period: form.course_offering_period.trim(),
        registration_day: toNum(form.registration_day) ?? 0,
        canvas_sessions_w1: toNum(form.canvas_sessions_w1),
        canvas_sessions_w2: toNum(form.canvas_sessions_w2),
        canvas_sessions_w3: toNum(form.canvas_sessions_w3),
        canvas_sessions_w4: toNum(form.canvas_sessions_w4),
        quiz1_w2: form.quiz1_w2,
        quiz2_w3: form.quiz2_w3,
        assignment1_plan_w4: form.assignment1_plan_w4,
        synthetic_group: form.synthetic_group,
        student_id: generateStudentId(form.display_name, existingIds),
      });
      setForm(EMPTY_FORM);
      onOpenChange(false);
    } catch (err) {
      setError(err.message || "Could not add the student.");
    } finally {
      setSubmitting(false);
    }
  };

  const assessmentSelect = (key, label) => (
    <div className="grid gap-1.5">
      <Label>{label}</Label>
      <Select value={form[key]} onValueChange={(v) => set(key, v)}>
        <SelectTrigger><SelectValue /></SelectTrigger>
        <SelectContent>
          {ASSESSMENT_OPTIONS.map((o) => (
            <SelectItem key={o} value={o}>{o}</SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!submitting) onOpenChange(o); }}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Add Student Record</DialogTitle>
          <DialogDescription>
            For a student who is not on the list. Blank Canvas sessions are stored as not recorded, never as zero. A
            student ID is generated automatically.
          </DialogDescription>
        </DialogHeader>
        <form className="space-y-6" onSubmit={handleSubmit}>
          {/* --- Student Details --- */}
          <section className="space-y-4">
            <SectionTitle>Student Details</SectionTitle>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="grid gap-1.5 sm:col-span-2">
                <Label htmlFor="display_name">Student Name</Label>
                <Input
                  id="display_name"
                  value={form.display_name}
                  onChange={(e) => set("display_name", e.target.value)}
                  placeholder="e.g. Jamie Taylor"
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="course_code">Course</Label>
                <Input id="course_code" value={form.course_code} onChange={(e) => set("course_code", e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="period">Semester</Label>
                <Input id="period" value={form.course_offering_period} onChange={(e) => set("course_offering_period", e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="registration_day">Enrolment Timing</Label>
                <Input
                  id="registration_day"
                  type="number"
                  value={form.registration_day}
                  onChange={(e) => set("registration_day", e.target.value)}
                />
                <p className="text-xs leading-relaxed text-muted-foreground">
                  Days relative to semester start: negative = before, 0 = on the start day, positive = after.
                </p>
              </div>
              <div className="grid gap-1.5">
                <Label>Synthetic Audit Group</Label>
                <Select value={form.synthetic_group} onValueChange={(v) => set("synthetic_group", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["A", "B", "C"].map((g) => (
                      <SelectItem key={g} value={g}>{g}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs leading-relaxed text-muted-foreground">
                  A fictional audit label used only for fairness analysis, never by the review rules.
                </p>
              </div>
            </div>
          </section>

          <Separator />

          {/* --- Weekly Canvas Activity --- */}
          <section className="space-y-3">
            <SectionTitle hint="Blank = not recorded">Weekly Canvas Activity</SectionTitle>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {["canvas_sessions_w1", "canvas_sessions_w2", "canvas_sessions_w3", "canvas_sessions_w4"].map((key, i) => (
                <div key={key} className="grid gap-1.5">
                  <Label className="text-muted-foreground">Week {i + 1}</Label>
                  <Input
                    type="number"
                    value={form[key]}
                    onChange={(e) => set(key, e.target.value)}
                    placeholder="—"
                  />
                </div>
              ))}
            </div>
          </section>

          <Separator />

          {/* --- Early Assessment Records --- */}
          <section className="space-y-3">
            <SectionTitle>Early Assessment Records</SectionTitle>
            <div className="grid gap-4 sm:grid-cols-3">
              {assessmentSelect("quiz1_w2", "Week 2 Quiz")}
              {assessmentSelect("quiz2_w3", "Week 3 Quiz")}
              {assessmentSelect("assignment1_plan_w4", "Week 4 Assignment Plan")}
            </div>
          </section>

          {error && <p className="text-sm text-destructive">{error}</p>}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? "Saving…" : "Save Student"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}