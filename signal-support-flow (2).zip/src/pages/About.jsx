import React from "react";
import { Shield, Eye, HandHeart, Database, Scale, FileText, Sparkles } from "lucide-react";
import PageHeader from "@/components/ui-signal/PageHeader";

const PRINCIPLES = [
  { icon: Sparkles, title: "Early support", text: "Identify potential concerns using information available by the end of Week 4." },
  { icon: Eye, title: "Explainability", text: "Every recommendation is understandable and traceable to actual data." },
  { icon: HandHeart, title: "Human control", text: "Advisors retain complete responsibility for decisions and interventions." },
  { icon: Shield, title: "Privacy", text: "Only fictional synthetic student records are used in this prototype." },
  { icon: Scale, title: "Fairness", text: "Group attributes are excluded from review rules and used only for separate diagnostic analysis." },
  { icon: FileText, title: "Transparency", text: "Confirmed observations are distinguished from missing information, assumptions and suggestions." },
];

const RULES = [
  { id: "R1", name: "Missed early assessments", text: "Two or more of three early assessments confirmed as Missed. Suggested: Academic skills support." },
  { id: "R2", name: "Canvas activity dropped", text: "Weeks 3 and 4 at or below 50% of a Weeks 1–2 baseline of at least four sessions. Suggested: Wellbeing check-in." },
  { id: "R3", name: "Late registration with low activity", text: "Registration after day 0 with Week 1 and Week 2 each below three sessions. Suggested: Enrolment and orientation support." },
  { id: "R4", name: "No activity for two consecutive weeks", text: "Zero recorded Canvas sessions in any two consecutive weeks. Suggested: Wellbeing check-in." },
];

export default function About() {
  return (
    <div>
      <PageHeader title="About SIGNAL" description="Methodology, explanations, privacy principles and prototype limitations." />
      <div className="page-content space-y-10">
        <section>
          <h2 className="font-heading text-lg font-semibold tracking-tight text-foreground">What SIGNAL is</h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            SIGNAL is an advisor-facing student engagement and early-support decision platform, developed as part of a University of Auckland INFOMGMT 399 capstone project. It helps Student Support Advisors identify students who may benefit from early academic or wellbeing assistance, understand the engagement signals behind those recommendations, and independently decide what action to take. SIGNAL is not a replacement for Canvas, a student-facing learning management system, or a dropout prediction system.
          </p>
        </section>

        <section>
          <h2 className="font-heading text-lg font-semibold tracking-tight text-foreground">Core principles</h2>
          <div className="mt-3 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {PRINCIPLES.map((p) => {
              const Icon = p.icon;
              return (
                <div key={p.title} className="rounded-2xl border border-border bg-card p-4 shadow-soft">
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-teal-soft">
                    <Icon className="h-[18px] w-[18px] text-teal" />
                  </div>
                  <h3 className="mt-3 text-sm font-semibold text-foreground">{p.title}</h3>
                  <p className="mt-1 text-xs text-muted-foreground">{p.text}</p>
                </div>
              );
            })}
          </div>
        </section>

        <section>
          <h2 className="font-heading text-lg font-semibold tracking-tight text-foreground">The four transparent rules</h2>
          <p className="mt-1 text-sm text-muted-foreground">No machine learning, dropout probability models, or hidden classifications. Every rule returns Matched, Not matched, or Could not check.</p>
          <div className="mt-3 space-y-3">
            {RULES.map((r) => (
              <div key={r.id} className="rounded-2xl border border-border bg-card p-4 shadow-soft">
                <h3 className="text-sm font-semibold text-foreground">{r.id}: {r.name}</h3>
                <p className="mt-1 text-xs text-muted-foreground">{r.text}</p>
              </div>
            ))}
          </div>
          <p className="mt-3 text-xs text-muted-foreground">
            A student enters the review queue when at least one enabled rule matches. The number of matched rules may guide reading order but is not a dropout-risk score. The combined suggested category follows a transparent priority: R1 → R4/R2 → R3.
          </p>
        </section>

        <section>
          <h2 className="font-heading text-lg font-semibold tracking-tight text-foreground">Privacy and responsible use</h2>
          <div className="mt-3 grid gap-4 lg:grid-cols-2">
            <div className="rounded-2xl border border-border bg-card p-4 shadow-soft">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-foreground"><Shield className="h-4 w-4 text-teal" /> Data handling</h3>
              <ul className="mt-2 space-y-1.5 text-xs text-muted-foreground list-disc pl-4">
                <li>Purpose limitation: support advisor review only.</li>
                <li>Data minimisation: only engagement signals needed by the rules.</li>
                <li>Group attributes are never used by the review-rule engine.</li>
                <li>Student names are never used in rule calculations.</li>
              </ul>
            </div>
            <div className="rounded-2xl border border-border bg-card p-4 shadow-soft">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-foreground"><Database className="h-4 w-4 text-violet" /> Retention and oversight</h3>
              <ul className="mt-2 space-y-1.5 text-xs text-muted-foreground list-disc pl-4">
                <li>Advisor decisions are temporary session memory in this prototype.</li>
                <li>No automated decision-making or student contact is triggered.</li>
                <li>All records are fictional and synthetic.</li>
                <li>NZ Privacy Act 2020 considerations would apply to any hypothetical real deployment.</li>
              </ul>
            </div>
          </div>
          <p className="mt-3 text-xs text-muted-foreground">
            This prototype does not guarantee legal compliance. It does not enable real Canvas integration, student messaging, automatic intervention, or handling of real student records.
          </p>
        </section>

        <section>
          <h2 className="font-heading text-lg font-semibold tracking-tight text-foreground">Limitations</h2>
          <ul className="mt-2 space-y-1.5 text-sm text-muted-foreground list-disc pl-5">
            <li>SIGNAL uses one fictional course (BUSAN101, 2026S2) and 100 synthetic students.</li>
            <li>Information is available only up to the end of Week 4; no post-checkpoint outcomes are included.</li>
            <li>Missing observations are common and are never treated as zero activity or missed assessments.</li>
            <li>Fairness comparisons use small fictional groups and do not establish whether rules are fair.</li>
            <li>The assistant answers only supported, data-grounded questions and never invents student data.</li>
          </ul>
        </section>
      </div>
    </div>
  );
}