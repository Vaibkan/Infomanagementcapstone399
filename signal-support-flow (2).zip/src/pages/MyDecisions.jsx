import React from "react";
import { Link } from "react-router-dom";
import { ClipboardCheck, Check, Clock, X, ListChecks, Undo2, Info } from "lucide-react";
import { useSignal } from "@/lib/signalContext";
import PageHeader from "@/components/ui-signal/PageHeader";
import StatCard from "@/components/ui-signal/StatCard";
import EmptyState from "@/components/ui-signal/EmptyState";
import { Button } from "@/components/ui/button";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

const OUTCOME_META = {
  accept: { label: "Accepted next step", icon: Check, cls: "bg-teal-soft text-teal" },
  "follow-up": { label: "Follow up later", icon: Clock, cls: "bg-violet-soft text-violet" },
  "no-action": { label: "No action", icon: X, cls: "bg-muted text-muted-foreground" },
};

export default function MyDecisions() {
  const { decisions, undoDecision, computed } = useSignal();
  const listed = computed.filter((c) => c.listedForReview).length;
  const outstanding = listed - decisions.filter((d) => computed.find((c) => c.student_id === d.student_id && c.listedForReview)).length;

  const counts = {
    accept: decisions.filter((d) => d.outcome === "accept").length,
    "follow-up": decisions.filter((d) => d.outcome === "follow-up").length,
    "no-action": decisions.filter((d) => d.outcome === "no-action").length,
  };

  return (
    <div>
      <PageHeader
        title="My Decisions"
        description="A transparent record of decisions made in this session."
      />
      <div className="page-content space-y-6">
        <div className="rounded-xl border border-amber/30 bg-amber-soft px-4 py-3 text-sm text-amber">
          <Info className="mr-1.5 inline h-4 w-4" />
          Decisions are temporary for this demonstration and are not saved permanently. They are cleared when the application reloads.
        </div>

        <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
          <StatCard label="Decisions completed" value={decisions.length} icon={ClipboardCheck} tone="teal" />
          <StatCard label="Accepted next step" value={counts.accept} icon={Check} tone="teal" />
          <StatCard label="Follow up later" value={counts["follow-up"]} icon={Clock} tone="violet" />
          <StatCard label="No action" value={counts["no-action"]} icon={X} tone="neutral" />
          <StatCard label="Outstanding reviews" value={outstanding} icon={ListChecks} tone="amber" />
        </div>

        <div className="rounded-2xl border border-border bg-card shadow-soft">
          {decisions.length === 0 ? (
            <EmptyState
              icon={ClipboardCheck}
              title="No decisions recorded yet"
              description="Open the review queue and select a student to record your first decision."
              action={<Link to="/review"><Button>Open Review Queue</Button></Link>}
              className="m-4"
            />
          ) : (
            <div className="overflow-x-auto scrollbar-thin">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Outcome</TableHead>
                    <TableHead>Support category</TableHead>
                    <TableHead className="hidden lg:table-cell">Advisor note</TableHead>
                    <TableHead>Time</TableHead>
                    <TableHead className="w-20"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {decisions.map((d) => {
                    const meta = OUTCOME_META[d.outcome] || OUTCOME_META["no-action"];
                    const Icon = meta.icon;
                    return (
                      <TableRow key={d.id}>
                        <TableCell>
                          <Link to={`/student/${d.student_id}`} className="font-medium text-foreground hover:text-teal">
                            {d.display_name || d.student_id}
                          </Link>
                          <p className="text-xs text-muted-foreground">{d.student_id}</p>
                        </TableCell>
                        <TableCell>
                          <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${meta.cls}`}>
                            <Icon className="h-3.5 w-3.5" /> {meta.label}
                          </span>
                        </TableCell>
                        <TableCell className="text-sm text-foreground">{d.chosenCategory || "—"}</TableCell>
                        <TableCell className="hidden lg:table-cell max-w-[260px] text-xs text-muted-foreground">{d.note || "—"}</TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {new Date(d.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </TableCell>
                        <TableCell>
                          <button onClick={() => undoDecision(d.id)} className="inline-flex items-center gap-1 text-xs font-medium text-violet hover:underline">
                            <Undo2 className="h-3.5 w-3.5" /> Undo
                          </button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}