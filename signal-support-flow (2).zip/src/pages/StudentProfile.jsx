import React, { useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { ArrowLeft, Check, Clock, X, Undo2, Info, ChevronDown, ChevronRight } from "lucide-react";
import { useSignal } from "@/lib/signalContext";
import { SUPPORT_CATEGORIES } from "@/lib/ruleEngine";
import RulePill from "@/components/ui-signal/RulePill";
import AssessmentBadge from "@/components/ui-signal/AssessmentBadge";
import EmptyState from "@/components/ui-signal/EmptyState";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
  ReferenceLine,
} from "recharts";

const ASSESSMENTS = [
  { key: "quiz1_w2", name: "Quiz 1", week: "Week 2" },
  { key: "quiz2_w3", name: "Quiz 2", week: "Week 3" },
  { key: "assignment1_plan_w4", name: "Assignment 1 plan", week: "Week 4" },
];

function EngagementChart({ student }) {
  const weeks = ["canvas_sessions_w1", "canvas_sessions_w2", "canvas_sessions_w3", "canvas_sessions_w4"];
  const data = weeks.map((k, i) => ({
    week: `Week ${i + 1}`,
    sessions: student[k],
    isNull: student[k] == null,
  }));
  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-soft">
      <div className="mb-1 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-foreground">Canvas activity timeline</h3>
        <span className="text-xs text-muted-foreground">End of Week 4 checkpoint</span>
      </div>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={data} margin={{ left: -16, right: 12, top: 12, bottom: 4 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
          <XAxis dataKey="week" fontSize={11} stroke="hsl(var(--muted-foreground))" />
          <YAxis fontSize={11} stroke="hsl(var(--muted-foreground))" allowDecimals={false} />
          <Tooltip
            contentStyle={{
              borderRadius: 12,
              border: "1px solid hsl(var(--border))",
              boxShadow: "0 8px 24px rgba(28, 37, 54, 0.08)",
            }}
            formatter={(v, n, p) => (p.payload.isNull ? ["not recorded", "Sessions"] : [v, "Sessions"])}
          />
          <Bar dataKey="sessions" radius={[6, 6, 0, 0]} maxBarSize={48}>
            {data.map((d, i) => (
              <Cell key={i} fill={d.isNull ? "hsl(var(--border))" : d.sessions === 0 ? "hsl(var(--amber))" : "hsl(var(--teal))"} />
            ))}
          </Bar>
          <ReferenceLine x="Week 4" stroke="hsl(var(--accent))" strokeDasharray="4 4" />
        </BarChart>
      </ResponsiveContainer>
      <div className="mt-3 flex flex-wrap gap-4 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-teal" /> Recorded activity</span>
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-amber" /> Recorded zero</span>
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm border border-dashed border-border" /> Not recorded</span>
      </div>
    </div>
  );
}

function RuleCard({ result, quiet = false }) {
  const [open, setOpen] = useState(false);
  return (
    <div
      className={cn(
        "rounded-2xl border p-4 transition-all duration-200",
        quiet
          ? "border-border/70 bg-muted/30"
          : result.outcome === "Matched"
          ? "border-teal/25 bg-card shadow-soft"
          : "border-amber/25 bg-card shadow-soft"
      )}
    >
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-start justify-between gap-3 text-left"
        aria-expanded={open}
      >
        <div>
          <p className="text-sm font-semibold text-foreground">{result.rule}: {result.name}</p>
          <p className="mt-0.5 text-xs text-muted-foreground">{result.period}</p>
        </div>
        <div className="flex shrink-0 items-center gap-2 pt-0.5">
          <RulePill outcome={result.outcome} />
          <ChevronDown
            className={cn("h-4 w-4 text-muted-foreground transition-transform duration-200", open && "rotate-180")}
          />
        </div>
      </button>
      <p className="mt-3 text-sm leading-relaxed text-foreground">{result.explanation}</p>
      {result.outcome === "Matched" && !quiet && (
        <p className="mt-2.5 text-xs">
          <span className="text-muted-foreground">Suggested support: </span>
          <span className="font-medium text-teal">{result.suggestedCategory}</span>
        </p>
      )}
      <div
        className={cn(
          "grid transition-all duration-200",
          open ? "mt-3 grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
        )}
      >
        <div className="overflow-hidden">
          <div className="rounded-xl bg-muted/60 px-3.5 py-3 text-xs leading-relaxed text-muted-foreground">
            <p><span className="font-medium text-foreground/70">Criteria examined: </span>{result.examined}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function StudentProfile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { computedById, decisionsByLearner, addDecision, undoDecision, computed, loading } = useSignal();
  const data = computedById.get(id);

  const existing = decisionsByLearner.get(id);
  const [category, setCategory] = useState(data?.suggestedCategory || "General student support");
  const [note, setNote] = useState("");
  const [outcome, setOutcome] = useState(null);
  const [justSaved, setJustSaved] = useState(null);

  // re-sync when student changes
  React.useEffect(() => {
    if (data) {
      setCategory(data.suggestedCategory === "None" ? "General student support" : data.suggestedCategory);
      setNote("");
      setOutcome(null);
      setJustSaved(null);
    }
  }, [id]);

  if (loading) {
    return (
      <div className="page-content">
        <div className="flex items-center gap-4">
          <div className="h-14 w-14 animate-pulse rounded-2xl bg-muted" />
          <div className="space-y-2">
            <div className="h-5 w-48 animate-pulse rounded-md bg-muted" />
            <div className="h-3.5 w-64 animate-pulse rounded-md bg-muted" />
          </div>
        </div>
      </div>
    );
  }
  if (!data) {
    return (
      <div className="page-content">
        <EmptyState
          icon={Info}
          title="Student not found"
          description={`No student with ID ${id} was found in the cohort.`}
          action={<Button onClick={() => navigate("/explorer")}>Back to Students</Button>}
        />
      </div>
    );
  }

  const s = data.student;
  const matchedIds = ["R1", "R2", "R3", "R4"].filter((r) => data.results[r].outcome === "Matched");
  const otherIds = ["R1", "R2", "R3", "R4"].filter((r) => data.results[r].outcome !== "Matched");

  const recordDecision = (chosenOutcome) => {
    const decision = {
      student_id: s.student_id,
      display_name: s.display_name,
      outcome: chosenOutcome,
      suggestedCategory: data.suggestedCategory,
      chosenCategory: category,
      note,
    };
    addDecision(decision);
    setOutcome(chosenOutcome);
    setJustSaved(chosenOutcome);
  };

  const handleUndo = () => {
    if (existing) undoDecision(existing.id);
    setOutcome(null);
    setJustSaved(null);
  };

  const nextStudent = () => {
    const listed = computed.filter((c) => c.listedForReview && !decisionsByLearner.has(c.student_id));
    const next = listed.find((c) => c.student_id !== id);
    if (next) navigate(`/student/${next.student_id}`);
    else navigate("/review");
  };

  const changedCategory = category !== (data.suggestedCategory === "None" ? "General student support" : data.suggestedCategory);
  const showRationalePrompt = changedCategory || outcome === "no-action";

  return (
    <div>
      {/* ---- Student overview ---- */}
      <div className="border-b border-border/80">
        <div className="mx-auto w-full max-w-[1152px] px-5 pb-6 pt-8 lg:px-8">
          <nav className="mb-4 flex items-center gap-1.5 text-xs text-muted-foreground">
            <Link to="/review" className="transition-colors hover:text-foreground">Review Queue</Link>
            <ChevronRight className="h-3 w-3" />
            <span className="text-foreground">{s.display_name}</span>
          </nav>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div className="flex items-start gap-4">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-teal-soft font-heading text-lg font-semibold text-teal">
                {s.display_name.split(" ").map((n) => n[0]).join("").slice(0, 2)}
              </div>
              <div>
                <h1 className="font-heading text-[27px] font-semibold leading-tight tracking-tight text-foreground">
                  {s.display_name}
                </h1>
                <p className="mt-0.5 text-sm text-muted-foreground">
                  <span className="font-mono">{s.student_id}</span> · {s.course_code} · {s.course_offering_period}
                </p>
                <div className="mt-2.5 flex flex-wrap items-center gap-2">
                  {data.listedForReview ? (
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-teal-soft px-2.5 py-1 text-xs font-medium text-teal">
                      <span className="h-1.5 w-1.5 rounded-full bg-teal" /> Listed for advisor review
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground">
                      <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground/60" /> Not currently listed
                    </span>
                  )}
                  <span className="text-xs text-muted-foreground">
                    {data.matchedCount} rule{data.matchedCount === 1 ? "" : "s"} matched
                  </span>
                  {data.dataGapCount > 0 && (
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-soft px-2.5 py-1 text-xs font-medium text-amber">
                      {data.dataGapCount} missing observation{data.dataGapCount === 1 ? "" : "s"}
                    </span>
                  )}
                </div>
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate(-1)} className="gap-1.5">
              <ArrowLeft className="h-4 w-4" /> Back
            </Button>
          </div>
        </div>
      </div>

      <div className="page-content space-y-8">
        {/* Student overview: activity chart + early assessments */}
        <section className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <EngagementChart student={s} />
          </div>
          <div className="rounded-2xl border border-border bg-card p-5 shadow-soft">
            <h3 className="mb-4 text-sm font-semibold text-foreground">Early assessments</h3>
            <div className="space-y-3.5">
              {ASSESSMENTS.map((a) => (
                <div key={a.key} className="flex items-center justify-between gap-2">
                  <div>
                    <p className="text-sm font-medium text-foreground">{a.name}</p>
                    <p className="text-xs text-muted-foreground">{a.week}</p>
                  </div>
                  <AssessmentBadge status={s[a.key]} />
                </div>
              ))}
            </div>
            <div className="mt-5 rounded-xl bg-muted/60 p-3.5 text-xs leading-relaxed text-muted-foreground">
              <p><span className="font-medium text-foreground/70">Registration day:</span> {s.registration_day ?? "not recorded"} {s.registration_day > 0 ? "(late)" : ""}</p>
              <p className="mt-1"><span className="font-medium text-foreground/70">Synthetic group:</span> {s.synthetic_group} <span className="text-muted-foreground/70">(audit label, not used by rules)</span></p>
            </div>
          </div>
        </section>

        {/* Engagement insights */}
        <section>
          <h2 className="font-heading text-lg font-semibold tracking-tight text-foreground">Engagement insights</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Each rule is evaluated independently against this student's recorded information. Select a card to see the
            complete criteria it examined.
          </p>
          {matchedIds.length > 0 ? (
            <div className="mt-4 grid gap-4 md:grid-cols-2">
              {matchedIds.map((r) => (
                <RuleCard key={r} result={data.results[r]} />
              ))}
            </div>
          ) : (
            <div className="mt-4">
              <EmptyState
                icon={Check}
                title="No matched rules"
                description="No enabled rule matched this student's recorded information. This does not imply the student needs no support."
              />
            </div>
          )}
          {otherIds.length > 0 && (
            <div className="mt-6">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Not matched or could not check
              </p>
              <div className="mt-3 grid gap-4 md:grid-cols-2">
                {otherIds.map((r) => (
                  <RuleCard key={r} result={data.results[r]} quiet />
                ))}
              </div>
            </div>
          )}
        </section>

        {/* Advisor decision */}
        <section className="rounded-2xl border border-border bg-card p-6 shadow-soft">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-heading text-lg font-semibold tracking-tight text-foreground">Advisor decision</h2>
              <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                Decisions are temporary for this demonstration and are not saved permanently. Recording a decision
                does not contact the student or trigger any intervention.
              </p>
            </div>
            {justSaved && (
              <div className="flex items-center gap-2 rounded-full bg-teal-soft px-3 py-1.5">
                <span className="text-xs font-medium text-teal">
                  {justSaved === "accept" ? "Accepted next step" : justSaved === "follow-up" ? "Follow up later" : "No action"} recorded
                </span>
                <button
                  onClick={handleUndo}
                  className="inline-flex items-center gap-1 text-xs font-medium text-violet hover:underline"
                >
                  <Undo2 className="h-3.5 w-3.5" /> Undo
                </button>
              </div>
            )}
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <Label className="text-xs font-medium text-muted-foreground">Support category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SUPPORT_CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
              {changedCategory && (
                <p className="mt-1.5 text-xs text-amber">
                  Changed from the suggested category. A brief rationale is recommended below.
                </p>
              )}
            </div>
            <div>
              <Label className="text-xs font-medium text-muted-foreground">Advisor note (optional)</Label>
              <Textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Relevant circumstances outside the available data…"
                className="mt-1.5 min-h-[80px]"
              />
            </div>
          </div>
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <Button onClick={() => recordDecision("accept")} className="gap-1.5">
              <Check className="h-4 w-4" /> Accept next step
            </Button>
            <Button onClick={() => recordDecision("follow-up")} variant="outline" className="gap-1.5">
              <Clock className="h-4 w-4" /> Follow up later
            </Button>
            <Button onClick={() => recordDecision("no-action")} variant="outline" className="gap-1.5">
              <X className="h-4 w-4" /> No action
            </Button>
            {justSaved && (
              <Button onClick={nextStudent} variant="ghost" className="ml-auto gap-1.5">
                Next awaiting student →
              </Button>
            )}
          </div>
          {showRationalePrompt && justSaved && !note && (
            <p className="mt-3 rounded-xl bg-amber-soft px-3.5 py-2.5 text-xs leading-relaxed text-amber">
              You picked a different option. Add a short note above to explain why.
            </p>
          )}
        </section>
      </div>
    </div>
  );
}