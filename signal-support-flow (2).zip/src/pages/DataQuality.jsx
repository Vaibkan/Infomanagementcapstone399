import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { AlertTriangle, Database, ChevronRight } from "lucide-react";
import { useSignal } from "@/lib/signalContext";
import PageHeader from "@/components/ui-signal/PageHeader";
import StatCard from "@/components/ui-signal/StatCard";
import EmptyState from "@/components/ui-signal/EmptyState";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { WEEK_LABELS } from "@/lib/ruleEngine";

const FIELD_LABELS = {
  canvas_sessions_w1: "Canvas Week 1",
  canvas_sessions_w2: "Canvas Week 2",
  canvas_sessions_w3: "Canvas Week 3",
  canvas_sessions_w4: "Canvas Week 4",
  quiz1_w2: "Quiz 1 (W2)",
  quiz2_w3: "Quiz 2 (W3)",
  assignment1_plan_w4: "Assignment 1 plan (W4)",
};

export default function DataQuality() {
  const { computed, loading } = useSignal();
  const [filter, setFilter] = useState("all");

  const stats = useMemo(() => {
    const canvasByWeek = WEEK_LABELS.map((label, i) => {
      const key = `canvas_sessions_w${i + 1}`;
      return { label, count: computed.filter((c) => c.student[key] == null).length };
    });
    const assessments = [
      { key: "quiz1_w2", label: "Quiz 1" },
      { key: "quiz2_w3", label: "Quiz 2" },
      { key: "assignment1_plan_w4", label: "Assignment 1 plan" },
    ].map((a) => ({ ...a, count: computed.filter((c) => c.student[a.key] === "Not recorded" || !c.student[a.key]).length }));
    const withGaps = computed.filter((c) => c.dataGapCount > 0);
    const uncheckable = computed.filter((c) => c.couldNotCheck.length > 0);
    return { canvasByWeek, assessments, withGaps, uncheckable };
  }, [computed]);

  const rows = useMemo(() => {
    return stats.withGaps.filter((c) => {
      if (filter === "canvas" && !c.missingFields.some((f) => f.startsWith("canvas"))) return false;
      if (filter === "assessments" && !c.missingFields.some((f) => !f.startsWith("canvas"))) return false;
      if (filter === "uncheckable" && c.couldNotCheck.length === 0) return false;
      return true;
    });
  }, [stats, filter]);

  return (
    <div>
      <PageHeader
        title="Data Quality"
        description="Missing information is a central concern. A missing observation is never the same as zero engagement or a missed assessment."
      />
      <div className="page-content space-y-6">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard label="Students with missing info" value={stats.withGaps.length} icon={AlertTriangle} tone="amber" />
          <StatCard label="Total missing observations" value={stats.withGaps.reduce((a, c) => a + c.dataGapCount, 0)} icon={Database} tone="amber" />
          <StatCard label="Students with uncheckable rules" value={stats.uncheckable.length} icon={AlertTriangle} tone="violet" />
          <StatCard label="Complete records" value={computed.length - stats.withGaps.length} icon={Database} tone="teal" />
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          <div className="rounded-2xl border border-border bg-card p-5 shadow-soft">
            <h3 className="mb-3 text-sm font-semibold text-foreground">Missing Canvas observations by week</h3>
            <div className="space-y-2">
              {stats.canvasByWeek.map((w) => (
                <div key={w.label} className="flex items-center gap-3">
                  <span className="w-20 text-xs text-muted-foreground">{w.label}</span>
                  <div className="h-6 flex-1 overflow-hidden rounded-md bg-muted">
                    <div className="h-full bg-amber/60" style={{ width: `${(w.count / computed.length) * 100}%` }} />
                  </div>
                  <span className="w-8 text-right text-xs font-medium text-foreground">{w.count}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-2xl border border-border bg-card p-5 shadow-soft">
            <h3 className="mb-3 text-sm font-semibold text-foreground">Unrecorded assessments by type</h3>
            <div className="space-y-2">
              {stats.assessments.map((a) => (
                <div key={a.key} className="flex items-center gap-3">
                  <span className="w-40 text-xs text-muted-foreground">{a.label}</span>
                  <div className="h-6 flex-1 overflow-hidden rounded-md bg-muted">
                    <div className="h-full bg-amber/60" style={{ width: `${(a.count / computed.length) * 100}%` }} />
                  </div>
                  <span className="w-8 text-right text-xs font-medium text-foreground">{a.count}</span>
                </div>
              ))}
            </div>
            <p className="mt-3 text-xs text-muted-foreground">"Not recorded" means the outcome is unknown, not that the assessment was missed.</p>
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-card shadow-soft">
          <div className="flex items-center justify-between border-b border-border p-4">
            <h3 className="text-sm font-semibold text-foreground">Students affected by missing information</h3>
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All missing data</SelectItem>
                <SelectItem value="canvas">Canvas records only</SelectItem>
                <SelectItem value="assessments">Assessments only</SelectItem>
                <SelectItem value="uncheckable">Uncheckable rules</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {loading ? (
            <div className="p-12 text-center text-sm text-muted-foreground">Loading…</div>
          ) : rows.length === 0 ? (
            <EmptyState icon={Database} title="No students match this filter" className="m-4" />
          ) : (
            <div className="overflow-x-auto scrollbar-thin">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Missing fields</TableHead>
                    <TableHead className="text-center">Count</TableHead>
                    <TableHead>Affected rules</TableHead>
                    <TableHead>Listed?</TableHead>
                    <TableHead className="w-10"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((c) => (
                    <TableRow key={c.student_id} className="group">
                      <TableCell>
                        <Link to={`/student/${c.student_id}`}>
                          <p className="font-medium text-foreground group-hover:text-teal">{c.student.display_name}</p>
                          <p className="text-xs text-muted-foreground">{c.student_id}</p>
                        </Link>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {c.missingFields.map((f) => FIELD_LABELS[f] || f).join(", ")}
                      </TableCell>
                      <TableCell className="text-center text-sm font-medium text-amber">{c.dataGapCount}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {c.couldNotCheck.length > 0 ? c.couldNotCheck.join(", ") : "—"}
                      </TableCell>
                      <TableCell>
                        {c.listedForReview ? (
                          <span className="text-xs font-medium text-teal">Yes</span>
                        ) : (
                          <span className="text-xs text-muted-foreground">No</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Link to={`/student/${c.student_id}`}>
                          <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-teal" />
                        </Link>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}