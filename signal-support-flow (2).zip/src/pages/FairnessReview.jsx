import React, { useMemo } from "react";
import { Scale, Info } from "lucide-react";
import { useSignal } from "@/lib/signalContext";
import PageHeader from "@/components/ui-signal/PageHeader";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell, LabelList,
} from "recharts";

export default function FairnessReview() {
  const { computed } = useSignal();

  const rows = useMemo(() => {
    const groups = ["A", "B", "C"];
    return groups.map((g) => {
      const members = computed.filter((c) => c.student.synthetic_group === g);
      const listed = members.filter((c) => c.listedForReview).length;
      return {
        group: `Group ${g}`,
        students: members.length,
        listed,
        rate: members.length ? listed / members.length : 0,
      };
    });
  }, [computed]);

  const overallListed = computed.filter((c) => c.listedForReview).length;
  const overallRate = computed.length ? overallListed / computed.length : 0;

  return (
    <div>
      <PageHeader
        title="Fairness Review"
        description="Group-level diagnostic comparisons. Group membership is never used to decide which students are listed."
      />
      <div className="page-content space-y-6">
        <div className="rounded-xl border border-amber/30 bg-amber-soft px-4 py-3 text-sm text-amber">
          <Info className="mr-1.5 inline h-4 w-4" />
          These comparisons use small, fictional groups and show differences in review-list inclusion only. They do not establish whether the rules are fair or discriminatory. Groups are synthetic audit labels, not real demographic classifications.
        </div>

        <div className="grid gap-4 lg:grid-cols-3">
          {rows.map((r) => {
            const diff = (r.rate - overallRate) * 100;
            return (
              <div key={r.group} className="rounded-2xl border border-border bg-card p-5 shadow-soft">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-foreground">{r.group}</h3>
                  <Scale className="h-4 w-4 text-muted-foreground" />
                </div>
                <div className="mt-3 flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-foreground">{Math.round(r.rate * 100)}%</span>
                  <span className="text-xs text-muted-foreground">review rate</span>
                </div>
                <p className="mt-2 text-xs text-muted-foreground">
                  {r.listed} of {r.students} students listed
                </p>
                <p className={`mt-1 text-xs font-medium ${Math.abs(diff) < 0.5 ? "text-muted-foreground" : diff > 0 ? "text-amber" : "text-teal"}`}>
                  {diff > 0 ? "+" : ""}{diff.toFixed(1)} pts vs cohort
                </p>
              </div>
            );
          })}
        </div>

        <div className="rounded-2xl border border-border bg-card p-5 shadow-soft">
          <h3 className="mb-1 text-sm font-semibold text-foreground">Review rate by group</h3>
          <p className="mb-4 text-xs text-muted-foreground">Overall cohort review rate: {Math.round(overallRate * 100)}% ({overallListed} of {computed.length})</p>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={rows} margin={{ left: -16, right: 24, top: 16, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="group" fontSize={12} stroke="hsl(var(--muted-foreground))" />
              <YAxis fontSize={11} stroke="hsl(var(--muted-foreground))" tickFormatter={(v) => `${v * 100}%`} domain={[0, 0.7]} />
              <Tooltip formatter={(v) => `${Math.round(v * 100)}%`} contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))" }} />
              <Bar dataKey="rate" radius={[6, 6, 0, 0]} maxBarSize={64}>
                {rows.map((r, i) => (
                  <Cell key={i} fill={r.rate >= overallRate ? "hsl(var(--teal))" : "hsl(var(--violet))"} />
                ))}
                <LabelList dataKey="rate" position="top" formatter={(v) => `${Math.round(v * 100)}%`} fontSize={12} fill="hsl(var(--foreground))" />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}