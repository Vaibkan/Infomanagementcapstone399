import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Users, Search, UserPlus, FlaskConical, Trash2, ChevronRight, Download } from "lucide-react";
import { useSignal } from "@/lib/signalContext";
import { buildExportCsv, downloadCsv, exportFilename } from "@/lib/csvExport";
import PageHeader from "@/components/ui-signal/PageHeader";
import MetricsRow from "@/components/ui-signal/MetricsRow";
import ActivityBars from "@/components/ui-signal/ActivityBars";
import EmptyState from "@/components/ui-signal/EmptyState";
import { Button } from "@/components/ui/button";
import AddStudentDialog from "@/components/AddStudentDialog";
import { generateStudentId } from "@/lib/studentId";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

export default function StudentExplorer() {
  const { computed, loading, addStudent, deleteStudent, decisions } = useSignal();
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [listFilter, setListFilter] = useState("all");
  const [completeness, setCompleteness] = useState("all");
  const [addOpen, setAddOpen] = useState(false);
  const [addingTest, setAddingTest] = useState(false);
  const [deletingId, setDeletingId] = useState(null);
  const [actionError, setActionError] = useState(null);

  const filtered = useMemo(() => {
    return computed.filter((c) => {
      if (listFilter === "listed" && !c.listedForReview) return false;
      if (listFilter === "not-listed" && c.listedForReview) return false;
      if (completeness === "complete" && c.dataGapCount > 0) return false;
      if (completeness === "incomplete" && c.dataGapCount === 0) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!c.student.display_name.toLowerCase().includes(q) && !c.student_id.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [computed, listFilter, completeness, search]);

  const listed = computed.filter((c) => c.listedForReview).length;
  const withGaps = computed.filter((c) => c.dataGapCount > 0).length;
  const existingIds = useMemo(() => new Set(computed.map((c) => c.student_id)), [computed]);

  const addTestStudent = async () => {
    setAddingTest(true);
    setActionError(null);
    try {
      const names = new Set(computed.map((c) => c.student.display_name));
      let n = 1;
      let name = "Test Student";
      while (names.has(name)) {
        n += 1;
        name = `Test Student ${n}`;
      }
      await addStudent({
        display_name: name,
        course_code: "BUSAN101",
        course_offering_period: "2026S2",
        registration_day: 5,
        canvas_sessions_w1: 3,
        canvas_sessions_w2: 1,
        canvas_sessions_w3: 0,
        canvas_sessions_w4: 0,
        quiz1_w2: "Missed",
        quiz2_w3: "Missed",
        assignment1_plan_w4: "Missed",
        synthetic_group: "A",
        student_id: generateStudentId(name, existingIds),
      });
    } catch (e) {
      setActionError(e.message || "Could not add the test student.");
    } finally {
      setAddingTest(false);
    }
  };

  const handleDelete = async (e, c) => {
    e.stopPropagation();
    if (!window.confirm(`Remove ${c.student.display_name} (${c.student_id}) from the dataset?`)) return;
    setDeletingId(c.student_id);
    setActionError(null);
    try {
      await deleteStudent(c.student_id);
    } catch (err) {
      setActionError(err.message || "Could not remove the student.");
    } finally {
      setDeletingId(null);
    }
  };

  const handleExport = () => {
    downloadCsv(exportFilename(), buildExportCsv(computed, decisions));
  };

  const mainReason = (c) =>
    c.listedForReview && c.matchedRules.length > 0
      ? c.matchedRules.map((r) => c.results[r].name).join(" · ")
      : "No matched rules";

  return (
    <div>
      <PageHeader
        title="Students"
        description="Explore student engagement and review information."
        actions={
          <>
            <Button variant="outline" onClick={handleExport} disabled={loading || computed.length === 0}>
              <Download className="mr-2 h-4 w-4" />
              Export CSV
            </Button>
            <Button variant="outline" onClick={addTestStudent} disabled={addingTest}>
              <FlaskConical className="mr-2 h-4 w-4" />
              {addingTest ? "Adding…" : "Add test student"}
            </Button>
            <Button onClick={() => setAddOpen(true)}>
              <UserPlus className="mr-2 h-4 w-4" />
              Add student
            </Button>
          </>
        }
      />
      <AddStudentDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        addStudent={addStudent}
        existingIds={existingIds}
      />
      <div className="page-content space-y-6">
        {actionError && (
          <p className="rounded-xl border border-destructive/20 bg-destructive/5 px-4 py-3 text-sm text-destructive">
            {actionError}
          </p>
        )}

        <MetricsRow
          items={[
            { label: "Students", value: computed.length },
            { label: "Listed for review", value: listed, tone: "teal" },
            { label: "Not currently listed", value: computed.length - listed },
            { label: "With missing information", value: withGaps, tone: "amber" },
          ]}
        />

        <div className="rounded-2xl border border-border bg-card shadow-soft">
          <div className="flex flex-col gap-3 border-b border-border/80 p-4 lg:flex-row lg:items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name or student ID…"
                className="pl-9"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <Select value={listFilter} onValueChange={setListFilter}>
                <SelectTrigger className="w-[170px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All students</SelectItem>
                  <SelectItem value="listed">Listed for review</SelectItem>
                  <SelectItem value="not-listed">Not currently listed</SelectItem>
                </SelectContent>
              </Select>
              <Select value={completeness} onValueChange={setCompleteness}>
                <SelectTrigger className="w-[170px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any completeness</SelectItem>
                  <SelectItem value="complete">Complete records</SelectItem>
                  <SelectItem value="incomplete">Some unavailable</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {loading ? (
            <div className="divide-y divide-border/60">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="flex items-center gap-4 px-5 py-4">
                  <div className="h-9 w-9 animate-pulse rounded-full bg-muted" />
                  <div className="h-4 w-44 animate-pulse rounded-md bg-muted" />
                  <div className="ml-auto h-4 w-28 animate-pulse rounded-md bg-muted" />
                  <div className="h-4 w-16 animate-pulse rounded-md bg-muted" />
                </div>
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <EmptyState
              icon={Users}
              title="No students match"
              description="Try adjusting the search or filters."
              className="m-4"
            />
          ) : (
            <div className="overflow-x-auto scrollbar-thin">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead className="hidden md:table-cell">Activity W1–W4</TableHead>
                    <TableHead className="hidden lg:table-cell">Main review reason</TableHead>
                    <TableHead>Review status</TableHead>
                    <TableHead className="hidden lg:table-cell">Data</TableHead>
                    <TableHead className="w-16"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((c) => {
                    const weeks = ["canvas_sessions_w1", "canvas_sessions_w2", "canvas_sessions_w3", "canvas_sessions_w4"].map((k) => c.student[k]);
                    return (
                      <TableRow
                        key={c.student_id}
                        className="group cursor-pointer transition-colors hover:bg-muted/40"
                        onClick={() => navigate(`/student/${c.student_id}`)}
                      >
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-muted text-xs font-semibold text-muted-foreground">
                              {c.student.display_name.split(" ").map((n) => n[0]).join("").slice(0, 2)}
                            </span>
                            <div>
                              <p className="font-medium text-foreground transition-colors group-hover:text-teal">{c.student.display_name}</p>
                              <p className="font-mono text-xs text-muted-foreground">{c.student_id}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          <div className="w-24"><ActivityBars weeks={weeks} height={24} /></div>
                        </TableCell>
                        <TableCell className="hidden max-w-[240px] text-sm lg:table-cell">
                          <span className={c.listedForReview ? "text-foreground" : "text-muted-foreground"}>
                            {mainReason(c)}
                          </span>
                        </TableCell>
                        <TableCell>
                          {c.listedForReview ? (
                            <span className="inline-flex items-center gap-1.5 rounded-full bg-teal-soft px-2.5 py-1 text-xs font-medium text-teal">
                              <span className="h-1.5 w-1.5 rounded-full bg-teal" /> Listed
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground">
                              Not listed
                            </span>
                          )}
                        </TableCell>
                        <TableCell className="hidden text-xs lg:table-cell">
                          {c.dataGapCount > 0 ? (
                            <span className="font-medium text-amber">{c.dataGapCount} missing</span>
                          ) : (
                            <span className="text-muted-foreground">Complete</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center justify-end gap-0.5">
                            <Button
                              variant="ghost"
                              className="h-8 w-8 p-0 text-muted-foreground/60 opacity-0 transition-all duration-200 hover:bg-destructive/10 hover:text-destructive group-hover:opacity-100"
                              onClick={(e) => handleDelete(e, c)}
                              disabled={deletingId === c.student_id}
                              aria-label={`Remove ${c.student.display_name}`}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                            <ChevronRight className="h-4 w-4 text-muted-foreground/60 transition-colors group-hover:text-teal" />
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </div>

        <p className="text-xs leading-relaxed text-muted-foreground">
          Not being listed does not imply a student needs no support. Detailed rule outcomes are shown on each
          student profile. Synthetic data.
        </p>
      </div>
    </div>
  );
}