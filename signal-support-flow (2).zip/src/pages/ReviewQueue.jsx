import React, { useMemo, useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { ListChecks, AlertTriangle, Search, ChevronRight } from "lucide-react";
import { useSignal } from "@/lib/signalContext";
import PageHeader from "@/components/ui-signal/PageHeader";
import MetricsRow from "@/components/ui-signal/MetricsRow";
import ActivityBars from "@/components/ui-signal/ActivityBars";
import RulePill from "@/components/ui-signal/RulePill";
import EmptyState from "@/components/ui-signal/EmptyState";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

const RULES = ["R1", "R2", "R3", "R4"];
const CATEGORIES = ["Academic skills support", "Wellbeing check-in", "Enrolment and orientation support"];

function CohortChart({ computed }) {
  const listed = computed.filter((c) => c.listedForReview);
  const unlisted = computed.filter((c) => !c.listedForReview);
  const avg = (arr, key) => {
    const vals = arr.map((c) => c.student[key]).filter((v) => v != null);
    return vals.length ? Math.round((vals.reduce((a, b) => a + b, 0) / vals.length) * 100) / 100 : null;
  };
  const weeks = ["canvas_sessions_w1", "canvas_sessions_w2", "canvas_sessions_w3", "canvas_sessions_w4"];
  const data = weeks.map((w, i) => ({ week: `Week ${i + 1}`, listed: avg(listed, w), unlisted: avg(unlisted, w) }));
  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-soft">
      <h3 className="text-sm font-semibold text-foreground">Average weekly Canvas sessions</h3>
      <p className="mb-4 text-xs leading-relaxed text-muted-foreground">
        Listed vs not listed. Averages use recorded observations only; null values are never replaced with zero.
      </p>
      <ResponsiveContainer width="100%" height={220}>
        <LineChart data={data} margin={{ left: -16, right: 12, top: 8, bottom: 4 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
          <XAxis dataKey="week" fontSize={11} stroke="hsl(var(--muted-foreground))" />
          <YAxis fontSize={11} stroke="hsl(var(--muted-foreground))" />
          <Tooltip
            contentStyle={{
              borderRadius: 12,
              border: "1px solid hsl(var(--border))",
              boxShadow: "0 8px 24px rgba(28, 37, 54, 0.08)",
            }}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Line type="monotone" dataKey="listed" name="Listed for review" stroke="hsl(var(--teal))" strokeWidth={2.5} dot={{ r: 3 }} connectNulls />
          <Line type="monotone" dataKey="unlisted" name="Not listed" stroke="hsl(var(--muted-foreground))" strokeWidth={2} strokeDasharray="5 4" dot={{ r: 3 }} connectNulls />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export default function ReviewQueue() {
  const { computed, loading, decisionsByLearner } = useSignal();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const [search, setSearch] = useState("");
  const [ruleFilter, setRuleFilter] = useState(params.get("rule") || "all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dataGapFilter, setDataGapFilter] = useState("all");
  const [sort, setSort] = useState("matches");

  useEffect(() => {
    const r = params.get("rule");
    if (r) setRuleFilter(r);
  }, [params]);

  const listed = useMemo(() => computed.filter((c) => c.listedForReview), [computed]);
  const total = computed.length;
  const dataGaps = computed.filter((c) => c.dataGapCount > 0).length;
  const reviewed = listed.filter((c) => decisionsByLearner.has(c.student_id)).length;
  const awaiting = listed.length - reviewed;

  const filtered = useMemo(() => {
    let arr = listed.filter((c) => {
      if (ruleFilter !== "all" && c.results[ruleFilter].outcome !== "Matched") return false;
      if (categoryFilter !== "all" && c.suggestedCategory !== categoryFilter) return false;
      if (statusFilter === "awaiting" && decisionsByLearner.has(c.student_id)) return false;
      if (statusFilter === "reviewed" && !decisionsByLearner.has(c.student_id)) return false;
      if (dataGapFilter === "with-gaps" && c.dataGapCount === 0) return false;
      if (dataGapFilter === "no-gaps" && c.dataGapCount > 0) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!c.student.display_name.toLowerCase().includes(q) && !c.student_id.toLowerCase().includes(q)) return false;
      }
      return true;
    });
    if (sort === "matches") arr = [...arr].sort((a, b) => b.matchedCount - a.matchedCount);
    if (sort === "gaps") arr = [...arr].sort((a, b) => b.dataGapCount - a.dataGapCount);
    if (sort === "name") arr = [...arr].sort((a, b) => a.student.display_name.localeCompare(b.student.display_name));
    return arr;
  }, [listed, ruleFilter, categoryFilter, statusFilter, dataGapFilter, search, sort, decisionsByLearner]);

  const setRule = (v) => {
    setRuleFilter(v);
    if (v === "all") setParams({});
    else setParams({ rule: v });
  };

  return (
    <div>
      <PageHeader
        title="Review Queue"
        description="Students whose engagement patterns meet one or more transparent rules. Being listed does not establish disengagement or likely withdrawal."
      />
      <div className="page-content space-y-6">
        <MetricsRow
          items={[
            { label: "Students in cohort", value: total },
            { label: "Listed for review", value: listed.length, tone: "teal" },
            { label: "Awaiting review", value: awaiting, sub: null },
            { label: "Reviewed this session", value: reviewed },
            { label: "With missing information", value: dataGaps, tone: "amber" },
          ]}
        />

        <CohortChart computed={computed} />

        <div className="rounded-2xl border border-border bg-card shadow-soft">
          <div className="flex flex-col gap-3 border-b border-border/80 p-4 lg:flex-row lg:items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name or student ID..."
                className="pl-9"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <Select value={ruleFilter} onValueChange={setRule}>
                <SelectTrigger className="w-[150px]"><SelectValue placeholder="Rule" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All rules</SelectItem>
                  {RULES.map((r) => <SelectItem key={r} value={r}>{r} matched</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-[180px]"><SelectValue placeholder="Category" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All categories</SelectItem>
                  {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[150px]"><SelectValue placeholder="Status" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="awaiting">Awaiting review</SelectItem>
                  <SelectItem value="reviewed">Reviewed</SelectItem>
                </SelectContent>
              </Select>
              <Select value={dataGapFilter} onValueChange={setDataGapFilter}>
                <SelectTrigger className="w-[140px]"><SelectValue placeholder="Data gaps" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any data</SelectItem>
                  <SelectItem value="with-gaps">With gaps</SelectItem>
                  <SelectItem value="no-gaps">No gaps</SelectItem>
                </SelectContent>
              </Select>
              <Select value={sort} onValueChange={setSort}>
                <SelectTrigger className="w-[150px]"><SelectValue placeholder="Sort" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="matches">Most matched rules</SelectItem>
                  <SelectItem value="gaps">Most data gaps</SelectItem>
                  <SelectItem value="name">Name (A-Z)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {loading ? (
            <div className="divide-y divide-border/60">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="flex items-center gap-4 px-5 py-4">
                  <div className="h-9 w-9 animate-pulse rounded-full bg-muted" />
                  <div className="h-4 w-44 animate-pulse rounded-md bg-muted" />
                  <div className="ml-auto h-4 w-28 animate-pulse rounded-md bg-muted" />
                  <div className="h-4 w-16 animate-pulse rounded-md bg-muted" />
                </div>
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <EmptyState
              icon={ListChecks}
              title="No students match these filters"
              description="Try adjusting the rule, category or search filters above."
              className="m-4"
            />
          ) : (
            <div className="overflow-x-auto scrollbar-thin">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead className="hidden md:table-cell">Activity W1–W4</TableHead>
                    <TableHead className="hidden md:table-cell">Main reason</TableHead>
                    <TableHead className="hidden xl:table-cell">Matched rules</TableHead>
                    <TableHead className="hidden lg:table-cell">Category</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-10"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((c) => {
                    const weeks = ["canvas_sessions_w1", "canvas_sessions_w2", "canvas_sessions_w3", "canvas_sessions_w4"].map((k) => c.student[k]);
                    const decided = decisionsByLearner.has(c.student_id);
                    const hasGaps = c.dataGapCount > 0;
                    return (
                      <TableRow
                        key={c.student_id}
                        className="group cursor-pointer transition-colors hover:bg-muted/40"
                        onClick={() => navigate(`/student/${c.student_id}`)}
                      >
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-muted text-xs font-semibold text-muted-foreground">
                              {c.student.display_name.split(" ").map((n) => n[0]).join("").slice(0, 2)}
                            </span>
                            <div>
                              <p className="font-medium text-foreground transition-colors group-hover:text-teal">
                                {c.student.display_name}
                                {hasGaps && (
                                  <span
                                    className="ml-1.5 inline-block h-1.5 w-1.5 -translate-y-px rounded-full bg-amber align-middle"
                                    title={`${c.dataGapCount} missing observation${c.dataGapCount === 1 ? "" : "s"}`}
                                  />
                                )}
                              </p>
                              <p className="font-mono text-xs text-muted-foreground">{c.student_id}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          <div className="w-24">
                            <ActivityBars weeks={weeks} height={24} />
                          </div>
                        </TableCell>
                        <TableCell className="hidden max-w-[240px] md:table-cell">
                          <span className="text-sm text-foreground">
                            {c.matchedRules.map((r) => c.results[r].name).join(" · ") || "—"}
                          </span>
                        </TableCell>
                        <TableCell className="hidden xl:table-cell">
                          <div className="flex flex-wrap gap-1">
                            {RULES.map((r) => (
                              <RulePill key={r} outcome={c.results[r].outcome} small />
                            ))}
                          </div>
                        </TableCell>
                        <TableCell className="hidden text-sm text-foreground lg:table-cell">{c.suggestedCategory}</TableCell>
                        <TableCell>
                          {decided ? (
                            <span className="inline-flex items-center gap-1.5 rounded-full bg-violet-soft px-2.5 py-1 text-xs font-medium text-violet">
                              <span className="h-1.5 w-1.5 rounded-full bg-violet" /> Reviewed
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground">
                              <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground/60" /> Awaiting
                            </span>
                          )}
                        </TableCell>
                        <TableCell>
                          <ChevronRight className="h-4 w-4 text-muted-foreground/60 transition-colors group-hover:text-teal" />
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </div>

        <p className="flex items-center gap-1.5 text-xs leading-relaxed text-muted-foreground">
          <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-amber" />
          An amber dot marks students with missing information. Missing data is never treated as zero activity.
          Synthetic data.
        </p>
      </div>
    </div>
  );
}