import React, { useMemo } from "react";
import { RotateCcw, Users, ArrowUp, ArrowDown } from "lucide-react";
import { useSignal } from "@/lib/signalContext";
import PageHeader from "@/components/ui-signal/PageHeader";
import StatCard from "@/components/ui-signal/StatCard";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DEFAULT_RULE_SETTINGS, evaluateAllRules } from "@/lib/ruleEngine";

function NumberField({ value, onChange, ...props }) {
  return (
    <Input
      type="number"
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
      className="w-24"
      {...props}
    />
  );
}

function RulePanel({ ruleId, name, description, enabled, onToggle, children, matchCount }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-soft">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-foreground">{ruleId}: {name}</h3>
            <span className="inline-flex items-center gap-1 rounded-full bg-teal-soft px-2 py-0.5 text-xs font-medium text-teal">
              <Users className="h-3 w-3" /> {matchCount} matching
            </span>
          </div>
          <p className="mt-1 text-xs text-muted-foreground">{description}</p>
        </div>
        <div className="flex items-center gap-2">
          <Label htmlFor={`${ruleId}-toggle`} className="text-xs text-muted-foreground">Enabled</Label>
          <Switch id={`${ruleId}-toggle`} checked={enabled} onCheckedChange={onToggle} />
        </div>
      </div>
      <div className={`mt-4 space-y-4 ${enabled ? "" : "opacity-50 pointer-events-none"}`}>{children}</div>
    </div>
  );
}

export default function RuleSettings() {
  const { ruleSettings, setRuleSettings, resetSettings, computed, students } = useSignal();

  const matchCounts = useMemo(() => {
    const counts = { R1: 0, R2: 0, R3: 0, R4: 0 };
    students.forEach((s) => {
      const r = evaluateAllRules(s, ruleSettings);
      if (r.results.R1.outcome === "Matched") counts.R1++;
      if (r.results.R2.outcome === "Matched") counts.R2++;
      if (r.results.R3.outcome === "Matched") counts.R3++;
      if (r.results.R4.outcome === "Matched") counts.R4++;
    });
    return counts;
  }, [students, ruleSettings]);

  const currentListed = useMemo(() => students.filter((s) => evaluateAllRules(s, ruleSettings).listedForReview), [students, ruleSettings]);
  const defaultListed = useMemo(() => students.filter((s) => evaluateAllRules(s, DEFAULT_RULE_SETTINGS).listedForReview), [students]);
  const currentIds = new Set(currentListed.map((s) => s.student_id));
  const defaultIds = new Set(defaultListed.map((s) => s.student_id));
  const added = currentListed.filter((s) => !defaultIds.has(s.student_id));
  const removed = defaultListed.filter((s) => !currentIds.has(s.student_id));
  const changed = JSON.stringify(ruleSettings) !== JSON.stringify(DEFAULT_RULE_SETTINGS);

  const set = (patch) => setRuleSettings((prev) => ({ ...prev, ...patch }));

  return (
    <div>
      <PageHeader
        title="Rule Settings"
        description="Transparent, configurable review rules. Adjustments demonstrate sensitivity, not validated thresholds."
        actions={
          changed ? (
            <Button variant="outline" onClick={resetSettings} className="gap-1.5">
              <RotateCcw className="h-4 w-4" /> Reset to default rules
            </Button>
          ) : null
        }
      />
      <div className="page-content space-y-6">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard label="Listed under current settings" value={currentListed.length} tone="teal" />
          <StatCard label="Listed under defaults" value={defaultListed.length} tone="neutral" />
          <StatCard label="Added by changes" value={added.length} icon={ArrowUp} tone="amber" />
          <StatCard label="Removed by changes" value={removed.length} icon={ArrowDown} tone="violet" />
        </div>

        {changed && (
          <div className="rounded-xl border border-border bg-muted/40 px-4 py-3 text-sm text-muted-foreground">
            <span className="font-medium text-foreground">{defaultListed.length}</span> students were listed under the default settings. The current settings list <span className="font-medium text-foreground">{currentListed.length}</span>.
          </div>
        )}

        <RulePanel
          ruleId="R1" name="Missed early assessments" description="Match if at least N of three early assessments (Quiz 1, Quiz 2, Assignment 1 plan) are confirmed as Missed."
          enabled={ruleSettings.r1_enabled} onToggle={(v) => set({ r1_enabled: v })} matchCount={matchCounts.R1}
        >
          <div>
            <Label className="text-xs font-medium">Minimum confirmed missed assessments (1–3)</Label>
            <div className="mt-2 flex items-center gap-4">
              <Slider value={[ruleSettings.r1_min_missed]} min={1} max={3} step={1} onValueChange={([v]) => set({ r1_min_missed: v })} className="flex-1" />
              <NumberField value={ruleSettings.r1_min_missed} min={1} max={3} onChange={(v) => set({ r1_min_missed: Math.max(1, Math.min(3, v)) })} />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">Suggested support: Academic skills support. "Not recorded" is never treated as "Missed".</p>
        </RulePanel>

        <RulePanel
          ruleId="R2" name="Canvas activity dropped" description="Weeks 3 and 4 must both be at or below a proportion of the Weeks 1–2 baseline, which must meet a minimum."
          enabled={ruleSettings.r2_enabled} onToggle={(v) => set({ r2_enabled: v })} matchCount={matchCounts.R2}
        >
          <div>
            <Label className="text-xs font-medium">Max remaining activity ratio: {ruleSettings.r2_max_ratio.toFixed(2)}</Label>
            <div className="mt-2 flex items-center gap-4">
              <Slider value={[ruleSettings.r2_max_ratio]} min={0.1} max={1} step={0.05} onValueChange={([v]) => set({ r2_max_ratio: v })} className="flex-1" />
              <NumberField value={ruleSettings.r2_max_ratio} min={0} max={1} step={0.05} onChange={(v) => set({ r2_max_ratio: v })} />
            </div>
          </div>
          <div>
            <Label className="text-xs font-medium">Minimum W1–W2 baseline sessions</Label>
            <div className="mt-2 flex items-center gap-4">
              <Slider value={[ruleSettings.r2_min_baseline]} min={0} max={10} step={1} onValueChange={([v]) => set({ r2_min_baseline: v })} className="flex-1" />
              <NumberField value={ruleSettings.r2_min_baseline} min={0} onChange={(v) => set({ r2_min_baseline: Math.max(0, v) })} />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">Suggested support: Wellbeing check-in. All four weekly observations must be recorded.</p>
        </RulePanel>

        <RulePanel
          ruleId="R3" name="Late registration with low activity" description="Registration after the cutoff day, with low Week 1 and Week 2 Canvas activity."
          enabled={ruleSettings.r3_enabled} onToggle={(v) => set({ r3_enabled: v })} matchCount={matchCounts.R3}
        >
          <div>
            <Label className="text-xs font-medium">Registration cutoff day (0 = after start)</Label>
            <div className="mt-2 flex items-center gap-4">
              <Slider value={[ruleSettings.r3_reg_cutoff]} min={-30} max={14} step={1} onValueChange={([v]) => set({ r3_reg_cutoff: v })} className="flex-1" />
              <NumberField value={ruleSettings.r3_reg_cutoff} onChange={(v) => set({ r3_reg_cutoff: v })} />
            </div>
          </div>
          <div>
            <Label className="text-xs font-medium">Low activity below (W1 and W2 each)</Label>
            <div className="mt-2 flex items-center gap-4">
              <Slider value={[ruleSettings.r3_low_activity]} min={0} max={10} step={1} onValueChange={([v]) => set({ r3_low_activity: v })} className="flex-1" />
              <NumberField value={ruleSettings.r3_low_activity} min={0} onChange={(v) => set({ r3_low_activity: Math.max(0, v) })} />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">Suggested support: Enrolment and orientation support.</p>
        </RulePanel>

        <RulePanel
          ruleId="R4" name="No activity for two consecutive weeks" description="Zero recorded Canvas sessions in any two consecutive weeks between Weeks 1 and 4."
          enabled={ruleSettings.r4_enabled} onToggle={(v) => set({ r4_enabled: v })} matchCount={matchCounts.R4}
        >
          <div>
            <Label className="text-xs font-medium">Consecutive zero-activity weeks required</Label>
            <p className="mt-1 text-xs text-muted-foreground">This prototype checks pairs of consecutive weeks (2). Only confirmed zero values count as inactivity.</p>
          </div>
          <p className="text-xs text-muted-foreground">Suggested support: Wellbeing check-in.</p>
        </RulePanel>

        {(added.length > 0 || removed.length > 0) && (
          <div className="grid gap-4 lg:grid-cols-2">
            {added.length > 0 && (
              <div className="rounded-2xl border border-amber/30 bg-amber-soft/40 p-4">
                <h3 className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-amber"><ArrowUp className="h-4 w-4" /> Added by current settings ({added.length})</h3>
                <div className="flex flex-wrap gap-1.5">
                  {added.map((s) => <span key={s.student_id} className="rounded-md bg-card px-2 py-1 text-xs text-foreground">{s.display_name}</span>)}
                </div>
              </div>
            )}
            {removed.length > 0 && (
              <div className="rounded-2xl border border-violet/30 bg-violet-soft/40 p-4">
                <h3 className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-violet"><ArrowDown className="h-4 w-4" /> Removed by current settings ({removed.length})</h3>
                <div className="flex flex-wrap gap-1.5">
                  {removed.map((s) => <span key={s.student_id} className="rounded-md bg-card px-2 py-1 text-xs text-foreground">{s.display_name}</span>)}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}