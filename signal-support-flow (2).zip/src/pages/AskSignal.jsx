import React, { useState, useRef, useEffect } from "react";
import { Send, Sparkles, MessageSquare, Search, ChevronDown } from "lucide-react";
import { useSignal } from "@/lib/signalContext";
import { interpretQuestion, SUGGESTED_QUESTIONS } from "@/lib/assistant";
import ResponseRenderer from "@/components/ResponseRenderer";
import Logo from "@/components/Logo";
import { cn } from "@/lib/utils";

const SUGGESTION_ICONS = {
  "Who may benefit from early support this week?": Sparkles,
  "Which students have declining Canvas activity?": Search,
  "Why was a particular student listed for review?": Search,
  "Which students have missing engagement information?": Search,
  "Which students missed early assessments?": Search,
  "Are review rates similar across student groups?": Search,
  "What decisions have I made so far?": Search,
  "Show me the overall engagement trends.": Search,
};

const DEFAULT_SUGGESTIONS = 4;

export default function AskSignal() {
  const { computed, decisions, loading } = useSignal();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [lastStudent, setLastStudent] = useState(null);
  const [showAllSuggestions, setShowAllSuggestions] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const ask = (question) => {
    if (!question.trim() || loading) return;
    const response = interpretQuestion(question, { computed, decisions, lastStudent });
    if (response.student) setLastStudent(response.student);
    setMessages((prev) => [...prev, { role: "user", text: question }, { role: "assistant", response }]);
    setInput("");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    ask(input);
  };

  const hasConversation = messages.length > 0;
  const shownSuggestions = showAllSuggestions
    ? SUGGESTED_QUESTIONS
    : SUGGESTED_QUESTIONS.slice(0, DEFAULT_SUGGESTIONS);
  const hiddenCount = SUGGESTED_QUESTIONS.length - DEFAULT_SUGGESTIONS;

  return (
    <div className="relative flex min-h-screen flex-col">
      {!hasConversation ? (
        // ---- Landing / hero ----
        <div className="relative flex flex-1 flex-col items-center justify-center px-5 py-16">
          <div className="hero-glow pointer-events-none absolute inset-x-0 top-0 h-[520px]" aria-hidden="true" />
          <div className="relative w-full max-w-[720px] animate-fade-in-up text-center">
            <div className="mb-7 flex justify-center">
              <Logo compact className="h-10 w-16" />
            </div>
            <h1 className="font-heading text-[40px] font-semibold leading-[1.12] tracking-[-0.02em] text-foreground sm:text-[46px]">
              Understand student engagement.
              <span className="mt-1.5 block text-teal">Support students earlier.</span>
            </h1>
            <p className="mx-auto mt-5 max-w-lg text-[15px] leading-relaxed text-muted-foreground">
              Explore engagement patterns, find students and make informed support decisions.
            </p>

            <form onSubmit={handleSubmit} className="mx-auto mt-9 w-full max-w-[720px]">
              <div className="flex items-center gap-2 rounded-2xl border border-border bg-card p-2 shadow-soft transition-all duration-200 focus-within:border-teal/40 focus-within:shadow-lift focus-within:ring-4 focus-within:ring-teal/10">
                <Search className="ml-2.5 h-[18px] w-[18px] shrink-0 text-muted-foreground" />
                <input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask SIGNAL about student engagement..."
                  className="flex-1 bg-transparent px-1 py-2.5 text-[15px] text-foreground outline-none placeholder:text-muted-foreground"
                  autoFocus
                />
                <button
                  type="submit"
                  disabled={!input.trim() || loading}
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm transition-all duration-200 hover:bg-primary/90 disabled:opacity-40"
                  aria-label="Ask SIGNAL"
                >
                  <Send className="h-4 w-4" />
                </button>
              </div>
            </form>

            <div className="mt-9">
              <div className="mx-auto grid w-full max-w-[640px] grid-cols-1 gap-2.5 sm:grid-cols-2">
                {shownSuggestions.map((q) => {
                  const Icon = SUGGESTION_ICONS[q] || Search;
                  return (
                    <button
                      key={q}
                      onClick={() => ask(q)}
                      className="group flex items-center justify-between gap-2 rounded-xl border border-border bg-card px-4 py-3 text-left text-sm font-medium text-foreground shadow-sm transition-all duration-200 hover:border-teal/35 hover:shadow-lift"
                    >
                      <span>{q}</span>
                      <Icon className="h-4 w-4 shrink-0 text-muted-foreground transition-colors duration-200 group-hover:text-teal" />
                    </button>
                  );
                })}
              </div>
              {hiddenCount > 0 && (
                <button
                  onClick={() => setShowAllSuggestions((v) => !v)}
                  className="mt-3.5 inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground transition-colors duration-200 hover:text-teal"
                >
                  <ChevronDown
                    className={cn("h-3.5 w-3.5 transition-transform duration-200", showAllSuggestions && "rotate-180")}
                  />
                  {showAllSuggestions ? "Fewer suggestions" : "More suggestions"}
                </button>
              )}
            </div>
          </div>
        </div>
      ) : (
        // ---- Conversation ----
        <div className="mx-auto flex h-screen w-full max-w-[760px] flex-col px-4 py-6">
          <div ref={scrollRef} className="flex-1 space-y-6 overflow-y-auto scrollbar-thin pb-4">
            {messages.map((m, i) =>
              m.role === "user" ? (
                <div key={i} className="flex animate-fade-in justify-end">
                  <div className="max-w-[85%] rounded-2xl rounded-br-md bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground shadow-sm">
                    {m.text}
                  </div>
                </div>
              ) : (
                <div key={i} className="flex animate-fade-in-up gap-3">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-teal-soft">
                    <MessageSquare className="h-4 w-4 text-teal" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <ResponseRenderer
                      response={m.response}
                      onFollowUp={(q) => ask(q)}
                    />
                  </div>
                </div>
              )
            )}
          </div>
          <form onSubmit={handleSubmit} className="border-t border-border pt-4">
            <div className="flex items-center gap-2 rounded-2xl border border-border bg-card p-2 shadow-soft transition-all duration-200 focus-within:border-teal/40 focus-within:ring-4 focus-within:ring-teal/10">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask a follow-up question..."
                className="flex-1 bg-transparent px-3 py-2.5 text-[15px] text-foreground outline-none placeholder:text-muted-foreground"
              />
              <button
                type="submit"
                disabled={!input.trim() || loading}
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm transition-all duration-200 hover:bg-primary/90 disabled:opacity-40"
                aria-label="Ask SIGNAL"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}