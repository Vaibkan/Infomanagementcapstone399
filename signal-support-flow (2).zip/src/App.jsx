import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import { SignalProvider } from '@/lib/signalContext';
import Layout from '@/components/Layout';
// Auth pages
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
// App pages
import AskSignal from '@/pages/AskSignal';
import ReviewQueue from '@/pages/ReviewQueue';
import StudentExplorer from '@/pages/StudentExplorer';
import StudentProfile from '@/pages/StudentProfile';
import DataQuality from '@/pages/DataQuality';
import MyDecisions from '@/pages/MyDecisions';
import FairnessReview from '@/pages/FairnessReview';
import RuleSettings from '@/pages/RuleSettings';
import About from '@/pages/About';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<SignalProvider><Layout /></SignalProvider>}>
          <Route path="/" element={<AskSignal />} />
          <Route path="/review" element={<ReviewQueue />} />
          <Route path="/explorer" element={<StudentExplorer />} />
          <Route path="/student/:id" element={<StudentProfile />} />
          <Route path="/data-quality" element={<DataQuality />} />
          <Route path="/decisions" element={<MyDecisions />} />
          <Route path="/fairness" element={<FairnessReview />} />
          <Route path="/rule-settings" element={<RuleSettings />} />
          <Route path="/about" element={<About />} />
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App